package tests;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pageObjects.LoginPage;

public class LoginInvalidInputTest extends BaseTest {
	
	@Override
	public void setupLogin() {
	}
	
	@Test (description="Test the login failed scenario - check that login failed, get the right message")
		public void LoginFailed() {
		  
			// -------------------------------------------------------
			// Initiate the login page object
			// -------------------------------------------------------	
			LoginPage loginPage = new LoginPage(driver);
			// -------------------------------------------------------
			// call the login methods from the login page - the login should have failed
			// -------------------------------------------------------			
			loginPage.login("locked_out_user","secret_sauce");
			// -------------------------------------------------------
			// actual - should get the error message after the login failed
			// -------------------------------------------------------
			String actual = loginPage.getErrorMsg();
			// -------------------------------------------------------
			// expected - the expected message after the login failed
			// -------------------------------------------------------		
			String expected = "Epic sadface: Sorry, this user has been locked out.";
			Assert.assertEquals(actual, expected);
		}
	  @Test(dataProvider="getData", description="use incorect login information")
		public void l2_loginFailed(String user,String password) {
			// -------------------------------------------------------
			// login failed
			// -------------------------------------------------------	
			LoginPage loginPage = new LoginPage(driver);
			// -------------------------------------------------------
			// Using the variables from the @DataProvider method
			// -------------------------------------------------------	
			loginPage.login(user, password);
			// -------------------------------------------------------
			// Should check if getting the right message
			// -------------------------------------------------------	 
			String expected = "Epic sadface: Username and password do not match any user in this service";
			String actual = loginPage.getErrorMsg();
			Assert.assertEquals(actual, expected);
		}

		
//		 Returning 2 dimensional object (like a table) Using the @DataProvider.
//		 the method above will get the parameters for each iteration.
		 
		@DataProvider
		public Object[][] getData(){
			Object[][] myData = {
					{"NULL_EX1","secret_sauce"},
					{"standard_user","1#0k"},
					{"standard_user","   "},
					{"standard_user","___"},
			};
			return myData;
		}
}
