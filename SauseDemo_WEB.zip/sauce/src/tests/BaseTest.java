package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;

import pageObjects.LoginPage;

public class BaseTest {
	public WebDriver driver;
	
	@BeforeClass
	public void setup() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\jekob\\Desktop\\Automation\\selenium\\drivers\\chromedriver.exe");

		driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.get("https://www.saucedemo.com/");
	}
	
	@BeforeClass
	public void setupLogin() {
		LoginPage lp = new LoginPage(driver);
		lp.login("standard_user", "secret_sauce");
	}
	
//	@AfterClass
//	public void tearDown() {
//		//driver.quit();
//	}
}
