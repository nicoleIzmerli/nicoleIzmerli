package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pageObjects.CheckoutPage;
import pageObjects.ItemPage;
import pageObjects.OverviewPage;
import pageObjects.ProductsPage;
import pageObjects.YourCartPage;

public class AddProductsTest extends BaseTest {

	@Test(description = "add 2 products to cart")
	public void tc02_addProducts() {
		ProductsPage pp = new ProductsPage(driver);
		pp.sortProducts("lohi");
		pp.chooseProduct("Sauce Labs Bike Light");

		ItemPage ip = new ItemPage(driver);
		ip.addToCart();
		ip.continueShopping();

		pp = new ProductsPage(driver);
		pp.chooseProduct("Sauce Labs Fleece Jacket");
		ip = new ItemPage(driver);
		ip.addToCart();
		ip.openAllItemsTab();
		int actual = pp.getNumOfItemsInCart();
		Assert.assertEquals(actual, 2);

		pp.openCart();
		YourCartPage yc = new YourCartPage(driver);
		CheckoutPage cp = new CheckoutPage(driver);
		yc.checkout();
		cp.continueCheckoutI();
		String actual1 = yc.getErrorMsgCheckoutI();
		System.out.println("data:"+actual1);
		Assert.assertEquals(actual1, "Error: First Name is required");
//		BasePage bp = new BasePage(driver);
//		bp.waiting(1000);
		cp.checkoutInfoFillText("Nicole", "Izmerli", "1234560");
		cp.continueCheckoutI();
		OverviewPage op = new OverviewPage(driver);
		boolean actual2 = op.getNumOfItemsInCheckoutTC();
		Assert.assertTrue(actual2);
		@SuppressWarnings("unused")
		String actual3 = op.getItemTotalCheckoutTC();
		Assert.assertEquals(actual3, "59.980000000000004");
		
		cp.finishCheckout();
		@SuppressWarnings("unused")
		boolean actual4 = cp.getcompleteHeaderTitle();
	}
}
