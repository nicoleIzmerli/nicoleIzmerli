
package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class YourCartPage extends BasePage {
	
	@FindBy(css = ".btn_action.btn_medium.checkout_button")
	private WebElement checkoutBtn;
	@FindBy(css=".shopping_cart_badge")
	private WebElement numOfItemsInCartLabel;
	@FindBy(css="#continue")
	private WebElement continueBtn;
	@FindBy(css=".error-message-container.error")
	private WebElement checkoutIerrorLabel;
	@FindBy(css="#first-name")
	private WebElement firstNameField;
	@FindBy(css="#last-name")
	private WebElement LastNameField;
	@FindBy(css="#postal-code")
	private WebElement codeField;
	@FindBy(css = ".cart_quantity")
	private int getNumOfItemsInCheckout;
	@FindBy(css = ".error-message-container h3")
	private WebElement getErrorMsgCheckoutInfo;
	
	public YourCartPage(WebDriver driver) {
		super(driver);
	}

	


	public void openCart() {
		
	}
	
	// -------------------------------------------------------
	// CHECKOUT: YOUR CART
	// -------------------------------------------------------
	public void checkout() {
		click(checkoutBtn);
	}
	
	//Validation
	public String getErrorMsgCheckoutI() {
		wait.until(ExpectedConditions.visibilityOf(getErrorMsgCheckoutInfo));
		if (getText(getErrorMsgCheckoutInfo).equalsIgnoreCase("Error: First Name is required")) {
			return getText(getErrorMsgCheckoutInfo);
		}
		else{
			return null;
		}
	}
	
	
}
