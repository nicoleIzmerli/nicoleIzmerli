package pageObjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class OverviewPage   extends BasePage{

	public OverviewPage(WebDriver driver) {
		super(driver);
	}
	@FindBy(css = ".cart_quantity")
	private List<WebElement> getNumOfItemsInCheckout1TC;
	@FindBy(css=".summary_info .summary_subtotal_label")
	private WebElement total;
	public boolean getNumOfItemsInCheckoutTC() {
		wait.until(ExpectedConditions.visibilityOfAllElements(getNumOfItemsInCheckout1TC));
		for (WebElement re : getNumOfItemsInCheckout1TC) {
			System.out.println(re.getText());
		}
		int sum=0 ;
		for (WebElement el : getNumOfItemsInCheckout1TC) {
			sum+=Integer.parseInt(el.getText());
		}
		System.out.println(sum);
		if (sum==2) {
			System.out.println("lallalalal");
			return true;
			
		} else
			return false;
	}
	public String getItemTotalCheckoutTC() {
		wait.until(ExpectedConditions.visibilityOf(total));
		System.out.println(total.getText());
		int from = total.getText().indexOf("$");
		return total.getText().substring(from+1, total.getText().length());
	}
}
