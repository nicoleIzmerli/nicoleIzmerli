package pageObjects;

import java.time.Duration;
import java.util.Set;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BasePage {
	
	static WebDriver driver;
	String mainWindow;
	WebDriverWait wait;
	@SuppressWarnings("static-access")
	public BasePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	}
	
	public String getText(WebElement el) {
		return el.getText();
	}
	
	public void fillText(WebElement el, String text) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
        //use executeScript() method and pass the arguments 
        //Here i pass values based on css style. Yellow background color with solid red color border. 
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid green;');", el);
		el.clear();
		el.sendKeys(text);
	}
	
	public void fillCharSequence(WebElement ell, CharSequence[] c) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
        //use executeScript() method and pass the arguments 
        //Here i pass values based on css style. Yellow background color with solid red color border. 
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid green;');", ell);
		ell.clear();
		ell.sendKeys(c);
	}

	public void click(WebElement el) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		// use executeScript() method and pass the arguments
		// Here i pass values based on css style. Yellow background color with solid red
		// color border.
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid green;');", el);
		el.click();
	}

	public void selectValue(WebElement el, String value) {
		Select s = new Select(el);
		s.selectByValue(value);
	}

	public String getTitle() {
		return driver.getTitle();
	}

	public void waiting(long milis) {
		try {
			Thread.sleep(milis);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void moveToNewWindow() {
		mainWindow = driver.getWindowHandle();
		Set<String> list = driver.getWindowHandles();
		for (String win : list) {
			System.out.println(win);
			driver.switchTo().window(win);
		}
	}

	public void moveToMainWindow() {
		driver.close();
		driver.switchTo().window(mainWindow);
	}
}
