package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;



public class LoginPage extends BasePage {

	@FindBy(css = "#user-name")
	private WebElement userField;
	@FindBy(css = "#password")
	private WebElement passwordField;
	@FindBy(css = "#login-button")
	private WebElement saveBtn;
	@FindBy(css = ".error-message-container.error")
	private WebElement errorLabel;

	public LoginPage(WebDriver driver) {
		super(driver);
	}

	public void login(String user, String password) {
		fillText(userField, user);
		fillText(passwordField, password);
		click(saveBtn);
	}

	// For Validation:
	public String getErrorMsg() {
		return getText(errorLabel);
	}

}	

