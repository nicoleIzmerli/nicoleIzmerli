
package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CheckoutPage extends YourCartPage {
	
	@FindBy(css = ".inventory_item_name")
	private String name;
	@FindBy(css = ".inventory_item_price")
	private double price;
	@FindBy(css = ".cart_quantity")
	private int quantity;
	@FindBy(css = "#checkout")
	private WebElement checkoutBtn;
	@FindBy(css=".submit-button.btn.btn_primary.cart_button.btn_action")
	private WebElement continueBtn;
	@FindBy(css=".error-message-container.error")
	private WebElement checkoutIerrorLabel;
	@FindBy(css="#first-name")
	private WebElement firstNameField;
	@FindBy(css="#last-name")
	private WebElement LastNameField;
	@FindBy(css="#postal-code")
	private WebElement codeField;
	@FindBy(css="#finish")
	private WebElement finishCheckoutBtn;
	@FindBy(css=".complete-header")
	private WebElement completeHeader;
	@FindBy(css = ".summary_subtotal_label")
	private String getItemTotalCheckout1TC;
	
	
	public CheckoutPage(WebDriver driver) {
		super(driver);
	}
	
	// -------------------------------------------------------
	// CHECKOUT: YOUR CART
	// -------------------------------------------------------
	public void checkout() {
		click(checkoutBtn);
	}
	
	// -------------------------------------------------------
	// CHECKOUT: YOUR INFORMATION
	// -------------------------------------------------------
	public void continueCheckoutI() {
		click(continueBtn);
		waiting(1000);
	}
	
	
	// -------------------------------------------------------
	// CHECKOUT: YOUR INFORMATION
	// -------------------------------------------------------
	public void checkoutInfoFillText(String firstName, String LastName, String code) {
		click(firstNameField);
		fillText(firstNameField, firstName);
		click(LastNameField);
		fillText(LastNameField, LastName);
		click(codeField);
		fillText(codeField, code);
	}
	
	// -------------------------------------------------------
	// CHECKOUT: OVERVIEW
	// -------------------------------------------------------
	public void ItemsInCheckout(String itemName, double itemPrice, int numPurchased) {
		name = itemName;
		price = itemPrice;
		quantity = numPurchased;
	}

/*	public String toString() {
		NumberFormat fmt = NumberFormat.getCurrencyInstance();
	
		return (name + "\t" + fmt.format(price) + "\t" + quantity + "\t" + fmt.format(price * quantity));
	
	}*/
	

	
	//Validations
//	public boolean getItemTotalCheckoutTC() {
//		if (getText_ItemTotalCheckoutTC(getItemTotalCheckout1TC).equalsIgnoreCase("59.980000000000004")) {
//			return true;
//		} else
//			return false;
//	}
	
	public void finishCheckout() {
		click(finishCheckoutBtn);
	}

	// -------------------------------------------------------
	// CHECKOUT: COMPLETE!
	// -------------------------------------------------------
	//Validations
	public boolean getcompleteHeaderTitle() {
		if (getText(completeHeader).equalsIgnoreCase("THANK YOU FOR YOUR ORDER")) {
			return true;
		} else
			return false;
	}

	public String getText_ItemTotalCheckoutTC(String getNumOfItemsInCheckout2) {
		return getNumOfItemsInCheckout2;
	}
}