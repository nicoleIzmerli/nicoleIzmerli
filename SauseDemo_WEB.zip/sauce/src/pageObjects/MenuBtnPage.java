package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MenuBtnPage extends BasePage {

	@FindBy(css=".shopping_cart_badge")
	private WebElement numOfItemsInCartLabel;
	@FindBy(css="#react-burger-menu-btn")
	private WebElement menuBtn;
	@FindBy(css="#inventory_sidebar_link")
	private WebElement menuAllItemsTab;
	@FindBy(css="#about_sidebar_link")
	private WebElement menuAboutTab;
	@FindBy(css="#logout_sidebar_link")
	private WebElement menuLogoutTab;
	@FindBy(css="#reset_sidebar_link")
	private WebElement menuResetAppStateTab;
	@FindBy(css="#react-burger-cross-btn")
	private WebElement menuCross;
	@FindBy(css=".social_twitter>a")
	private WebElement twitterBtn;
	@FindBy(css=".social_facebook>a")
	private WebElement facebookBtn;
	@FindBy(css=".social_linkedin>a")
	private WebElement linkedinBtn;
	
	public MenuBtnPage(WebDriver driver) {
		super(driver);
	}
	
	public void openCart() {
		
	}
	
	private void openMenuListing() {
		click(menuBtn);
		waiting(1000);
	}
	
	public void openAboutTab() {
		openMenuListing();
		click(menuAboutTab);
	}
	
	public void openAllItemsTab() {
		openMenuListing();
		click(menuAllItemsTab);
	}
		
	public void openLogoutTab() {
		openMenuListing();
		click(menuLogoutTab);
	}
	
	public void openResetAppStateTab() {
		openMenuListing();
		click(menuResetAppStateTab);
	}
	
	public void clickBurgerCross() {
		openMenuListing();
		click(menuCross);
	}
	
	public void openTwitter() {
		click(twitterBtn);
	}
	
	public void openFacebook() {
		click(facebookBtn);
	}
	
	public void openLinkedin() {
		click(linkedinBtn);
	}	
	
}
