package pageObjects;

import java.text.NumberFormat;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ItemPage extends MenuBtnPage {

	public ItemPage(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(css = ".btn_primary")
	private WebElement addToCartBtn;
	@FindBy(css = "#back-to-products")
	private WebElement continueShoppingBtn;
	@FindBy(css = ".btn.btn_secondary.btn_small.cart_button")
	private WebElement removeItem;
	@FindBy(css = ".inventory_item_name")
	private WebElement inventoryItemLink;
	
//	@FindBy(css = ".btn_secondary.back.btn_medium")
//	private WebElement continueShoppingBtn;
	
	private String name;
	private double price;
	private int quantity;

	// -------------------------------------------------------
	// Create a new item with the given attributes.
	// -------------------------------------------------------
	public void Item(String itemName, double itemPrice, int numPurchased) {
		name = itemName;
		price = itemPrice;
		quantity = numPurchased;
	}

	public String toString() {
		NumberFormat fmt = NumberFormat.getCurrencyInstance();

		return (name + "\t" + fmt.format(price) + "\t" + quantity + "\t" + fmt.format(price * quantity));

	}

	// -------------------------------------------------
	// Returns the unit price of the item
	// -------------------------------------------------
	public double getPrice() {
		return price;
	}

	// -------------------------------------------------
	// Returns the name of the item
	// -------------------------------------------------
	public String getName() {
		return name;
	}

	// -------------------------------------------------
	// Returns the quantity of the item
	// -------------------------------------------------
	public int getQuantity() {
		return quantity;
	}

	// -------------------------------------------------
	// others
	// -------------------------------------------------
	public void addToCart() {
		click(addToCartBtn);
	}

	public void continueShopping() {
		click(continueShoppingBtn);
	}

	public void remove() {
		click(removeItem);
	}

	public void inventoryLinkToItem() {
		click(inventoryItemLink);
	}
	
}
