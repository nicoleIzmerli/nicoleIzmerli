package pageObjects;

public class TwitterPage {

}
