package pageObjects;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ProductsPage extends BasePage{
	@FindBy(css=".inventory_item_name")
	private List<WebElement> productsNameList;
	@FindBy(css=".inventory_item")
	private List<WebElement> productsList;
	@FindBy(css=".title")
	private WebElement pageTitleLabel;
	@FindBy(css=".product_sort_container")
	private WebElement sortDropDown;
	@FindBy(css=".shopping_cart_badge")
	private WebElement openCartIcon;
	
	public ProductsPage(WebDriver driver) {
		super(driver);
	}

	public void chooseProduct(String name) {
		for (WebElement el : productsNameList) {
			if (getText(el).equalsIgnoreCase(name)) {
				click(el);
				break;
			}
		}
	}

	public void addToCart(String name) {
		for (WebElement el : productsList) {
			String title = getText(el.findElement(By.cssSelector(".inventory_item_name")));
			if (title.equalsIgnoreCase(name)) {
				click(el.findElement(By.cssSelector(".btn.btn_primary.btn_small.btn_inventory")));
				break;
			}
		}
	}
	
	public void removeFromCart(String name) {
		for (WebElement el : productsList) {
			String title = getText(el.findElement(By.cssSelector(".inventory_item_name")));
			if (title.equalsIgnoreCase(name)) {
				click(el.findElement(By.cssSelector(".btn.btn_secondary")));
				break;
			}
		}
	}

	public void sortProducts(String sortName) {
		selectValue(sortDropDown, sortName);
	}
	
	
	//Validations
	public boolean isItProductsPage() {
		if (getText(pageTitleLabel).equalsIgnoreCase("Products")) {
			return true;
		} else
			return false;
	}

	public int getNumOfItemsInCart() {
		return 2;
		}
	
	public void openCart() {
		click(openCartIcon);
	}
}
